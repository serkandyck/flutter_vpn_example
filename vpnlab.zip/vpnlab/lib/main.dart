import 'package:flutter/material.dart';
import 'package:vpnlab/app.dart';

import 'package:firebase_crashlytics/firebase_crashlytics.dart';

void main() async {
  Crashlytics.instance.enableInDevMode = true;
  FlutterError.onError = (FlutterErrorDetails details) {
    Crashlytics.instance.onError(details);
  };
  runApp(new App());
}
